title: 'centos7下安装yum记录（yum命令失败：cannot find a valid baseurl for repo: base/7/x86_64，卸载后重新安装，并且配置国内yum源）'
date: '2019-09-22 00:50:44'
updated: '2019-09-22 10:18:48'
tags: [linux]
permalink: /linux
---
  

网上找了好久，都过时了，自己鼓捣了半天，终于安装完成，记录一下。  
  
  
  

## 第一步：先看本地yum是否安装  
  
  

直接linux下输入yum查看  
![null](https://img-blog.csdnimg.cn/2019061317134922.png)![在这里插入图片描述](https://img-blog.csdnimg.cn/2019061317134922.png)  
![null](https://img-blog.csdnimg.cn/20190613171423434.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzM5Njg4MTk1,size_16,color_FFFFFF,t_70)![在这里插入图片描述](https://img-blog.csdnimg.cn/20190613171423434.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzM5Njg4MTk1,size_16,color_FFFFFF,t_70)  
提示这样的都是安装成功的，可以跳过安装卸载这步，直接看第四步。提示别的就是安装失败了，需要卸载重装。  
  

##  **第二步：卸载**  
  

这步我都是网上搜索的命令，最后卸完了，输入yum没有提示上面的就行，命令没记录，大概是这几个，可以参考下：  
rpm -qa yum ---查看yum（安装了的话会提示具体的，如下图没有的话就不用卸载）  
![null](https://img-blog.csdnimg.cn/20190613171940690.png)![在这里插入图片描述](https://img-blog.csdnimg.cn/20190613171940690.png)  
rpm -qa | grep yum | xargs rpm -e --nodeps --卸载  
  

##  **第三部：安装yum**  
  

这一步我是找的百度经验的，链接直接粘过来：  
https://jingyan.baidu.com/article/ce09321bbde1de2bff858f9a.html  
这个一定要到自己对应的版本去找，需要按照图上的地址一步一步来，这里要注意的是第七步命令会报错，这里改下图片里面的命令，使得rpm安装时忽略依赖：  
rpm -ivh yum-* --nodeps --force  
安装完后执行第一步的命令应该是成功的。  
  

##  **第四步：yum命令失败解决**  
  

我的失败报错是这个，别的可能不适用：  
**cannot find a valid baseurl for repo: base/7/x86_64**  
这个报错是因为yum配置源不对的问题，这个配置文件在/etc/yum.repos.d/ 目录下的CentOS-Base.repo（简单的来说就是下载一个阿里或者163的yum源配置文件，文件名字不一样的改成CentOS-Base.repo）  

    ---下载阿里云yum镜像源  
    1、备份  
    mv /etc/yum.repos.d/CentOS-Base.repo /etc/yum.repos.d/CentOS-Base.repo.backup  
    2、下载新的CentOS-Base.repo 到/etc/yum.repos.d/  
    CentOS 5  
    wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-5.repo  
    或者  
    curl -o /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-5.repo  
    CentOS 6  
    wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-6.repo  
    或者  
    curl -o /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-6.repo  
    CentOS 7  
    wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo  
    或者  
    curl -o /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo  
    3、之后运行 yum clean all，yum makecache 生成缓存  
       
    ----163yum镜像源  
      
    第一步：备份你的原镜像文件，以免出错后可以恢复。  
    mv /etc/yum.repos.d/CentOS-Base.repo /etc/yum.repos.d/CentOS-Base.repo.backup     
    第二步：下载新的CentOS-Base.repo 到/etc/yum.repos.d/  
    CentOS 5  
    wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.163.com/.help/CentOS5-Base-163.repo  
    CentOS 6  
    wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.163.com/.help/CentOS6-Base-163.repo  
    CentOS 7  
    wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.163.com/.help/CentOS7-Base-163.repo  
    3、之后运行 yum clean all，yum makecache 生成缓存  

这里执行yum makecache时候会报404的错误，是因为对应的地址没有资源。  
我们打开文件，修改baseurl为正确的地址就好，下面附我改完的，你需要去对应网址看看有没有这个路径。  

     # CentOS-Base.repo  
    #  
    # The mirror system uses the connecting IP address of the client and the  
    # update status of each mirror to pick mirrors that are updated to and  
    # geographically close to the client.  You should use this for CentOS updates  
    # unless you are manually picking other mirrors.  
    #  
    # If the mirrorlist= does not work for you, as a fall back you can try the   
    # remarked out baseurl= line instead.  
    #  
    #  
       
    [base]  
    name=CentOS-$releasever - Base - mirrors.aliyun.com  
    failovermethod=priority  
    baseurl=http://mirrors.aliyun.com/centos/7/os/x86_64/  
            http://mirrors.aliyuncs.com/centos/7/os/x86_64/  
            http://mirrors.cloud.aliyuncs.com/centos/7/os/x86_64/  
    gpgcheck=1  
    gpgkey=http://mirrors.aliyun.com/centos/RPM-GPG-KEY-CentOS-7  
       
    #released updates   
    [updates]  
    name=CentOS-$releasever - Updates - mirrors.aliyun.com  
    failovermethod=priority  
    baseurl=http://mirrors.aliyun.com/centos/7/updates/x86_64/  
            http://mirrors.aliyuncs.com/centos/7/updates/x86_64/  
            http://mirrors.cloud.aliyuncs.com/centos/7/updates/x86_64/  
    gpgcheck=1  
    gpgkey=http://mirrors.aliyun.com/centos/RPM-GPG-KEY-CentOS-7  
       
    #additional packages that may be useful  
    [extras]  
    name=CentOS-$releasever - Extras - mirrors.aliyun.com  
    failovermethod=priority  
    baseurl=http://mirrors.aliyun.com/centos/7/extras/x86_64/  
            http://mirrors.aliyuncs.com/centos/7/extras/x86_64/  
            http://mirrors.cloud.aliyuncs.com/centos/7/extras/x86_64/  
    gpgcheck=1  
    gpgkey=http://mirrors.aliyun.com/centos/RPM-GPG-KEY-CentOS-7  
       
    #additional packages that extend functionality of existing packages  
    [centosplus]  
    name=CentOS-$releasever - Plus - mirrors.aliyun.com  
    failovermethod=priority  
    baseurl=http://mirrors.aliyun.com/centos/7/centosplus/x86_64/  
            http://mirrors.aliyuncs.com/centos/7/centosplus/x86_64/  
            http://mirrors.cloud.aliyuncs.com/centos/7/centosplus/x86_64/  
    gpgcheck=1  
    enabled=0  
    gpgkey=http://mirrors.aliyun.com/centos/RPM-GPG-KEY-CentOS-7  
       
    #contrib - packages by Centos Users  
    [contrib]  
    name=CentOS-$releasever - Contrib - mirrors.aliyun.com  
    failovermethod=priority  
    baseurl=http://mirrors.aliyun.com/centos/7/contrib/x86_64/  
            http://mirrors.aliyuncs.com/centos/7/contrib/x86_64/  
            http://mirrors.cloud.aliyuncs.com/centos/7/contrib/x86_64/  
    gpgcheck=1  
    enabled=0  
    gpgkey=http://mirrors.aliyun.com/centos/RPM-GPG-KEY-CentOS-7  
  

改完后执行yum命令就可以正常执行了。  
  

